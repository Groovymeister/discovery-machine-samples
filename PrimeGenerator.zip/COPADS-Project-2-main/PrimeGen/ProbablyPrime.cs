/* 
Name: John West
File: ProbablyPrime.cs
Description: Static class for IsProbablyPrime extension method
*/

using System.Numerics;
using System.Security.Cryptography;

/// <summary>
/// Static class for IsProbablyPrime method so rest of program's methods
/// do not need to be defined statically
/// </summary>
public static class ProbablyPrime {

    /// <summary>
    /// Implements Miller-Rabin algorithm for testing primality
    /// </summary>
    /// <param name="value">BigInteger to be tested</param>
    /// <param name="k">Number of witnesses, or rounds of testing to perform</param>
    /// <returns>Boolean containing true if number is probably prime, false otherwise</returns>
    public static Boolean IsProbablyPrime(this BigInteger value, int k = 10){

        BigInteger d = value - 1;
        int r = 0;

        while (d % 2 == 0){
            d = d / 2;
            r += 1;
        }
        RandomNumberGenerator rng = RandomNumberGenerator.Create();
        for (int i = 0; i < k; i++){
            BigInteger a = RandomBigInt(2, value - 2, rng);
            BigInteger x = BigInteger.ModPow(a, d, value);
            if (x == 1 ||  x == value - 1){
                continue;
            }

            for (int j = 0; j < r - 1; j++){
                x = BigInteger.ModPow(x, 2, value);
                if (x == value - 1){
                    break;
                }
            }

            if (x == value - 1){
                continue;
            }

            return false;

        }

        return true;
    }

    /// <summary>
    /// Utility method for generating large big integers within a range
    /// Used within IsProbablyPrime method
    /// </summary>
    /// <param name="min">Minimum number of the range</param>
    /// <param name="max">Maximum number of the range</param>
    /// <param name="rng">RandomNumberGenerator for generating random bytes</param>
    /// <returns>The randomly generated BigInteger</returns>
    public static BigInteger RandomBigInt(BigInteger min, BigInteger max, RandomNumberGenerator rng){
        BigInteger randomValue = 0;

        while (randomValue < min || randomValue > max){
            byte[] randomBytes = new byte[max.GetByteCount()];
            rng.GetBytes(randomBytes);
            randomValue = new BigInteger(randomBytes);
        } 

        return randomValue;
    }
}